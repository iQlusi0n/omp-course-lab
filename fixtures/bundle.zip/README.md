# bundle.zip

A tiny archive used by the omp-course archive-reading exercise.

Members:
- README.md        this file
- data/sample.csv  five order rows in the same shape as data/lab.sqlite
- config.json      example client configuration

The bundle is rebuilt by `python3 tools/make_bundle.py`; it is committed so the
exercise works without running anything first.
